﻿
namespace Ex_Divers_OPP_17_12_21
{
    class Regulations
    {
        protected string regulations;
        
        
        public Regulations(string regulations)
        {
            SetRegulation(regulations); 
        }
        public Regulations(Regulations regObj)
        {
            SetRegulation(regObj.regulations);
        }
        public string GetRegulation() { return regulations; }

        public void SetRegulation(string regulations) { this.regulations = regulations; }

        public override string ToString()
        {
            return $"{regulations}";
        }




    }
}
