﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex_Divers_OPP_17_12_21
{
    class Rank
    {
        string rank, descriptionRank;
       
        string clubName;
        DateTime dateRank;
        int stars = 0;



        //public Rank(string rank, string descriptionRank)
        //{
        //    this.rank = rank;
        //    this.descriptionRank = descriptionRank;
        //}
        public Rank(string rank, string descriptionRank, string clubName, DateTime dateRank, int stars)
        {
            this.rank = rank;
            this.descriptionRank = descriptionRank;
            this.clubName = clubName;
            this.dateRank = dateRank;
            this.stars = stars;
        }

        public Rank(Rank obj)
        {
            this.rank = obj.rank;
            this.descriptionRank = obj.descriptionRank;
            this.clubName=obj.clubName; 
            this.dateRank = obj.dateRank;
            this.stars=obj.stars;   
        }

        public string GetRank() { return rank; }
        public string GetDescriptionRank() { return descriptionRank; }
        public string GetRankClubName() { return clubName; }
        public DateTime GetClubDate() { return dateRank; }
        public int GetStars() { return stars; }


        public void SetRank(string rank) { this.rank = rank; }
        public void SetStars(int stars) { this.stars = stars; }
        public void SetDescriptionRank(string descriptionRank) { this.descriptionRank = descriptionRank; }


        public override string ToString()
        {
            return $"Rank: {this.rank} Description: {this.descriptionRank}\nClub Name:{this.clubName} Date:{this.dateRank:d}";
        }

    }
}
