﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;


namespace Ex_Divers_OPP_17_12_21
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");
            int choiceUserWelcomePage;
            int choiceUserMenuLogin = 0;
            int choiceClubFromList = 7;
            int sumOfPartners = 0;

            //Time
            DateTime dateTime1 = new DateTime(1994, 05, 31);

            //אתרי צלילה עבור אילת , מקסיקו,וריו
            SiteCountry[] siteCountryEilat = new SiteCountry[2];
            siteCountryEilat[0] = new SiteCountry("DolphinReef", "Sweet", 30.5);
            siteCountryEilat[1] = new SiteCountry("Coral Reserve Beach", "Sweet", 50);

            SiteCountry[] siteCountriesRio = new SiteCountry[3];
            siteCountriesRio[0] = new SiteCountry("InAcqua", "Salty", 15.77);
            siteCountriesRio[1] = new SiteCountry("XDivers", "Salty", 10.7);
            siteCountriesRio[2] = new SiteCountry("Atlantis", "Salty", 90.1);

            SiteCountry[] siteCountriesMexico = new SiteCountry[2];
            siteCountriesMexico[0] = new SiteCountry("Dressel", "Sweet", 5);
            siteCountriesMexico[1] = new SiteCountry("Blue Life", "Sweet", 25);

            //יצירת תנאים עבור מדינות
            Regulations firstRegulation = new Regulations("1. be 12 years old and above\n 2. Own Personal diving certification\n 3. have a Diving insurance");
            Regulations secondRegulation = new Regulations("1. be 21 years old and above\n 2. Own Personal diving certification\n 3. Corona certificate valid");

            //יצירת מערך מדינות
            Country[] countryArray = new Country[10];
            countryArray[0] = new Country("Israel", firstRegulation);
            countryArray[1] = new Country("Brazil", secondRegulation);
            countryArray[2] = new Country("Zanzibar", firstRegulation);
            countryArray[3] = new Country("Thailand", secondRegulation);
            countryArray[4] = new Country("Mexico", firstRegulation);
            countryArray[5] = new Country();

            //Rank[] ranksArr = new Rank[3];
            //ranksArr[0] = new Rank(" - * - ", "One Star - Open water diver",place,date);
            //ranksArr[1] = new Rank(" - * * - ", "Two Stars - Advanced open water");
            //ranksArr[2] = new Rank(" - * * * - ", "Three Stars - Master Diver");


            //יצירת מערך משתשמים והטמעה של משתמש מערכת דיפולטי
            Diver[] diversUserArray = new Diver[5];
            diversUserArray[0] = new Diver(123, "Refael", "Zrihan", dateTime1, "rz123@gmail.com", "123");
            diversUserArray[1] = new Diver(456, "Barak", "Stein", new DateTime(1997, 02, 17), "barak@gmail.com", "456");

            //יצירת מערך עבור משתמשים רשומים חדשים שנוצרים במהלך הרשמה
            Diver[] currentPartnersArray = new Diver[diversUserArray.Length];
            currentPartnersArray[sumOfPartners] = new Diver();

            // יצירת מערך מדריכים 
            Instructor[] instructors = new Instructor[3];
            instructors[0] = new Instructor(diversUserArray[0].GetIdDiver(), diversUserArray[0].GetFirstNameDiver(), diversUserArray[0].GetLastNameDiver(), diversUserArray[0].GetBirthDateDiver(), diversUserArray[0].GetEmailDiver(), diversUserArray[0].GetPasswordDiver(), new DateTime(2019, 07, 22), new DateTime(2022, 01, 02));
            instructors[1] = new Instructor(diversUserArray[1].GetIdDiver(), diversUserArray[1].GetFirstNameDiver(), diversUserArray[1].GetLastNameDiver(), diversUserArray[1].GetBirthDateDiver(), diversUserArray[1].GetEmailDiver(), diversUserArray[1].GetPasswordDiver(), new DateTime(2020, 05, 31), new DateTime(2020, 10, 19));
            instructors[2] = new Instructor(205670, "Donald", "Trump", new DateTime(1955, 10, 09), "DonaldUSA@gmail.com", "99999999", new DateTime(2001, 08, 11), new DateTime(2009, 03, 31));


            //מועדוני צלילה במדינות שונות
            DivingClub[] divingClubs = new DivingClub[7];
            divingClubs[0] = new DivingClub("EilatDive", countryArray[0], "Eliraz", "South Beach,Eilat", "6374044", "eliraz@dolphinreef.co.il", "s12h56hr77k", siteCountryEilat, instructors[0]);
            divingClubs[1] = new DivingClub("Sdot-Yam Dive", countryArray[0], "Mosh", "Odem 3, Eilat", "6103230", "seamor2013@gmail.com", "s7h56hr902k", siteCountryEilat, null, "www.seamordiving.com");
            divingClubs[2] = new DivingClub("Rio Club", countryArray[1], "Cláudio", "Copacabana ,Rio de Janeiro", "88888565", "claud45@gmail.com", "s22h56hr80k", siteCountriesRio, instructors[1]);
            divingClubs[3] = new DivingClub("Zanzibar Club", countryArray[2], "Adam", "Odem 3, Zanzibar-City", "425798105", "adamZanizbar@gmail.com", "s4h5446hr24k", siteCountryEilat);
            divingClubs[4] = new DivingClub("Thiland Scuba Dive", countryArray[3], "Sirivannavari", "Odem 3, Koh Tao", "057256423", "bankokLan820@gmail.com", "s1h55hr33k", siteCountryEilat, null, "www.kohtaoscubaclub.com");
            divingClubs[5] = new DivingClub("Mexico Club", countryArray[4], "Pablo", "Odem 3, Playa-Del-Carmen", "3636479", "plata_5552013@gmail.com", "s53h55hr512k", siteCountriesMexico, instructors[2], "www.calendly.com");
            divingClubs[6] = new DivingClub();

            // 0    1    5
            int lengthOfLogBooks = 0;

            Equipment[] equipmentArray = new Equipment[9];
            equipmentArray[0] = new Equipment(0, "Knife");
            equipmentArray[1] = new Equipment(1, "Compass");
            equipmentArray[2] = new Equipment(2, "Milkshake");
            equipmentArray[3] = new Equipment(3, "Hook");
            equipmentArray[4] = new Equipment(4, "Flair");
            equipmentArray[5] = new Equipment(5, "Gas Mask");
            equipmentArray[6] = new Equipment(6, "Oxyigen Bottle");
            equipmentArray[7] = new Equipment(7, "Dive Suit");
            equipmentArray[8] = new Equipment(8, "Camera");



            DiveingBook[] logBook = new DiveingBook[10];
            logBook[0] = new DiveingBook(diversUserArray[0], diversUserArray[1], instructors[0], divingClubs[0], siteCountryEilat[0], countryArray[0], 32, 1, new DateTime(2021, 07, 20), new DateTime(2021, 07, 20, 15, 30, 00), new DateTime(2021, 07, 20, 18, 17, 00));



            DiveingBook[] currentLogBook = new DiveingBook[logBook.Length];
            currentLogBook[0] = new DiveingBook(logBook[0]);
            try
            {

                do
                {
                    ShowFirstMenu();
                    choiceUserWelcomePage = int.Parse(Console.ReadLine());
                    ValidateFirstMenuInput();
                    HandleChoise();
                    Console.ReadKey();
                    Console.Clear();
                } while (true);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }

            void ShowFirstMenu()
            {
                Console.WriteLine($"User Name: \t\t\t\tDiveClub: \t\t\t\tDive-Partners:{sumOfPartners}");
                Console.WriteLine("Welcome To DeepDiver 2.0\n========================");
                Console.Write("Select:\n 1.  User Login\n 2.  Register System\n 3.  Exit\nPlease Choose a Number:");
            }
            void ValidateFirstMenuInput()
            {
                while (!(choiceUserWelcomePage >= 1 && choiceUserWelcomePage <= 3))
                {
                    Console.WriteLine("--Worng Number!--\nPlease Choose a Number 1-3:");
                    choiceUserWelcomePage = int.Parse(Console.ReadLine());
                }
            }
            void HandleChoise()
            {
                switch (choiceUserWelcomePage)
                {
                    //Login :
                    case 1:
                        CaseUserLogin();
                        break;

                    case 2:
                        CaseRegister();
                        break;

                    case 3:
                        return;
                }
            }
            void CaseUserLogin()
            {
                Console.Write("\t\t\tEnter User ID:");
                int userDiverId = int.Parse(Console.ReadLine());
                Console.Write("\t\t\tEnter User Password:");
                string userDiverPassword = Console.ReadLine();
                for (int i = 0; i < diversUserArray.Length; i++)
                {
                    if (diversUserArray[i] != null)
                    {
                        if (userDiverId.Equals(diversUserArray[i].GetIdDiver()) && (userDiverPassword.Equals(diversUserArray[i].GetPasswordDiver())))
                        {
                            Console.Clear();
                            do
                            {
                                Console.WriteLine($"Diver Name:{diversUserArray[i].GetFirstNameDiver()} {diversUserArray[i].GetLastNameDiver()}  \t\t\t\tDiveClub:{divingClubs[choiceClubFromList - 1].GetClubName()} \t\t\t\tDive-Partners:{sumOfPartners}");
                                Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");
                                Console.WriteLine("\t\t\t\t\t\t\tWelcome !");
                                Console.Write("Select:\n\n 1.  Add Dive\n 2.  Enter DiveClub\n 3.  Add Diving Parteners\n 4.  Display Diving Regualtions By Country\n 5.  Display Profile\n 6.  Display Club Ditails\n 7.  Logout\n\nPlease Choose a Number:");
                                choiceUserMenuLogin = int.Parse(Console.ReadLine());
                                switch (choiceUserMenuLogin)
                                {
                                    case 1:
                                        if (divingClubs[choiceClubFromList - 1].GetClubName() == null || sumOfPartners == 0)
                                        {
                                            Console.WriteLine("Choose a dive club OR add more partners");
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;
                                        }

                                        Console.WriteLine("Enter dive Site Index:");
                                        int choiceIndexSite;
                                        for (int l = 0; l < divingClubs[choiceClubFromList - 1].GetSiteCountryArray().Length; l++)
                                        {
                                            Console.WriteLine(l + ")" + divingClubs[choiceClubFromList - 1].GetSiteCountryArray()[l].GetSiteName());
                                        }
                                        int lengthSiteArr = divingClubs[choiceClubFromList - 1].GetSiteCountryArray().Length;


                                        choiceIndexSite = int.Parse(Console.ReadLine());
                                        while (!(choiceIndexSite >= 0 && choiceIndexSite <= lengthSiteArr))
                                        {
                                            Console.WriteLine("Not a Valid Selection\nTry again..");
                                            choiceIndexSite = int.Parse(Console.ReadLine());
                                        }


                                        Console.WriteLine(divingClubs[choiceClubFromList - 1].GetSiteCountryArray()[choiceIndexSite].GetSiteName());
                                        Console.WriteLine($"Enter Tide: 0 = Low, 1 = High");
                                        byte tideChoice = byte.Parse(Console.ReadLine());
                                        Console.WriteLine($"Enter Temperature: -20°C - 60°C");
                                        int temperatureChoice = int.Parse(Console.ReadLine());
                                        Console.WriteLine($"Enter Dive Date : dd/mm/yyyy");
                                        string dateDive = Console.ReadLine();
                                        DateTime dateTimeToCheck = DateTime.Parse(dateDive);
                                        Console.WriteLine($"Enter Start Dive Time: HH:MM");
                                        string startTimeDive = Console.ReadLine();
                                        Console.WriteLine($"Enter End Dive Time: HH:MM");
                                        string endTimeDive = Console.ReadLine();

                                        int choiceGear;
                                        List<Equipment> equipmentList = new List<Equipment>();
                                        do
                                        {
                                            Console.WriteLine("Press 1 To Add Gear or 0 to Continue:");
                                            choiceGear = int.Parse(Console.ReadLine());

                                            while (!(choiceGear == 1 || choiceGear == 0))
                                            {
                                                Console.WriteLine("Worng Choice...Please Try Again!\nPress 1 To Add Gear or 0 to Continue:");
                                                choiceGear = int.Parse(Console.ReadLine());
                                            }
                                            if (choiceGear == 0)
                                            {
                                                break;
                                            }
                                            if (choiceGear == 1)
                                            {
                                                Console.WriteLine("Select Index from the Following list:");
                                                for (int equipIndex = 0; equipIndex < equipmentArray.Length; equipIndex++)
                                                {
                                                    Console.WriteLine($"{equipIndex}) {equipmentArray[equipIndex].GetEquipmentType()}");
                                                }
                                                int choiceGearFromList = int.Parse(Console.ReadLine());
                                                for (int equipment = 0; equipment < equipmentArray.Length; equipment++)
                                                {
                                                    if (choiceGearFromList == equipmentArray[equipment].GetEquipmentId())
                                                    {
                                                        Equipment temp = (Equipment)equipmentArray[equipment].Clone();

                                                        Console.WriteLine("Enter Amount(1-20)");
                                                        int amount = int.Parse(Console.ReadLine());
                                                        temp.SetAmount(amount);
                                                        Console.WriteLine("Write a Description or Enter to Continue");
                                                        string desc = Console.ReadLine();
                                                        temp.SetDescriptionPerGear(desc);
                                                        equipmentList.Add(temp);

                                                        foreach (Equipment equip in equipmentList)
                                                        {
                                                            Console.WriteLine(equip.ToString());
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                        } while (true);


                                        for (int o = 0; o < instructors.Length; o++)
                                        {
                                            if (instructors[o].GetIdDiver() == null)
                                            {
                                                break;
                                            }

                                            else if (instructors[o].Equals(divingClubs[choiceClubFromList - 1].GetInstructor()) && (dateTimeToCheck >= instructors[o].GetStartWorkDay() && dateTimeToCheck <= instructors[o].GetEndWorkDay()))
                                            {
                                                for (int log = 0; log < logBook.Length; log++)
                                                {
                                                    if (logBook[log] == null)
                                                    {
                                                        lengthOfLogBooks++;
                                                        logBook[log] = new DiveingBook(diversUserArray[i], currentPartnersArray[sumOfPartners - 1], divingClubs[choiceClubFromList - 1].GetInstructor(), divingClubs[choiceClubFromList - 1], divingClubs[choiceClubFromList - 1].GetSiteCountryArray()[choiceIndexSite], divingClubs[choiceClubFromList - 1].GetCountry(), temperatureChoice, tideChoice, dateTimeToCheck, DateTime.Parse(startTimeDive), DateTime.Parse(endTimeDive), equipmentList.ToArray());

                                                        int diveCounter = diversUserArray[i].GetDiveCount();

                                                        diveCounter++;
                                                        diversUserArray[i].SetDiveCount(diveCounter);









                                                        currentLogBook[lengthOfLogBooks] = new DiveingBook(diversUserArray[i], currentPartnersArray[sumOfPartners - 1], divingClubs[choiceClubFromList - 1].GetInstructor(), divingClubs[choiceClubFromList - 1], divingClubs[choiceClubFromList - 1].GetSiteCountryArray()[choiceIndexSite], divingClubs[choiceClubFromList - 1].GetCountry(), temperatureChoice, tideChoice, dateTimeToCheck, DateTime.Parse(startTimeDive), DateTime.Parse(endTimeDive), equipmentList.ToArray());

                                                        int divePartnerCounter = currentLogBook[lengthOfLogBooks].GetPartnerDiver().GetDiveCount();


                                                        divePartnerCounter++;
                                                        Console.WriteLine(divePartnerCounter);
                                                        currentLogBook[lengthOfLogBooks].GetPartnerDiver().SetDiveCount(divePartnerCounter);


                                                        Console.WriteLine("\n" + logBook[log]);
                                                        Console.WriteLine("\nDive Added Succefully!\n");
                                                        Console.WriteLine($"Dive was also added to: {currentPartnersArray[sumOfPartners - 1].GetFirstNameDiver()}");

                                                        break;
                                                    }
                                                }
                                                break;
                                            }
                                            Console.WriteLine("Unconfirmed Dive - There werent instarctors working at the club at the given date\nPress Enter");
                                        }
                                        Console.ReadKey();
                                        Console.Clear();
                                        break;
                                    case 2:
                                        Console.WriteLine("Enter Dive Club Name --OR-- Enter Country Name (type 'list' to show all dive clubs)");
                                        string choiseDiveClub = Console.ReadLine();
                                        if (choiseDiveClub.Equals("list"))
                                        {
                                            Console.WriteLine("Enter the club Number you wish to dive from:");
                                            for (int j = 0; j < divingClubs.Length; j++)
                                            {
                                                if (divingClubs[j].GetClubName() == null)
                                                {
                                                    break;
                                                }
                                                Console.WriteLine($"{j + 1}. {divingClubs[j].GetClubName()}\t{divingClubs[j].GetCountry().GetCountryName()}\n");
                                            }
                                            Console.Write("Type a Number from the list:");
                                            choiceClubFromList = int.Parse(Console.ReadLine());
                                            while (!(choiceClubFromList >= 1 && choiceClubFromList < divingClubs.Length))
                                            {
                                                Console.Write("Not a Valid Selection! Type a Number from the list:");
                                                choiceClubFromList = int.Parse(Console.ReadLine());
                                            }

                                            Console.WriteLine($"You Choose {divingClubs[choiceClubFromList - 1].GetClubName()}");
                                            Console.ReadKey();
                                            Console.Clear();
                                            break;
                                        }
                                        for (int l = 0; l < countryArray.Length; l++)
                                        {
                                            if (countryArray[l].GetCountryName() == null)
                                            {
                                                break;
                                            }
                                            if (countryArray[l].GetCountryName().Equals(choiseDiveClub))
                                            {
                                                for (int t = 0; t < divingClubs.Length; t++)
                                                {
                                                    if (divingClubs[t].GetClubName() == null)
                                                    {
                                                        break;
                                                    }
                                                    if (divingClubs[t].GetCountry().GetCountryName().Equals(choiseDiveClub))
                                                    {
                                                        Console.WriteLine($"{t + 1}. {divingClubs[t].GetClubName()}\n");

                                                    }

                                                }
                                                //TODO: תקינות קלט עבור בחירת מועדון צלילה מתוך רשימת מדינות 
                                                Console.Write("Type a Number from the list:");
                                                choiceClubFromList = int.Parse(Console.ReadLine());
                                                while (!(choiceClubFromList >= 1 && choiceClubFromList < divingClubs.Length))
                                                {
                                                    Console.Write("Not a Valid Selection! Type a Number from the list:");
                                                    choiceClubFromList = int.Parse(Console.ReadLine());
                                                }

                                                Console.WriteLine($"You Choose {divingClubs[choiceClubFromList - 1].GetClubName()}");
                                                break;
                                            }
                                        }


                                        for (int k = 0; k < divingClubs.Length; k++)
                                        {
                                            if (divingClubs[k].GetClubName() == null)
                                            {
                                                break;
                                            }
                                            if (divingClubs[k].GetClubName().Equals(choiseDiveClub))
                                            {
                                                Console.WriteLine($"You Choose {divingClubs[k].GetClubName()}");
                                                choiceClubFromList = ++k;
                                                break;
                                            }
                                        }

                                        Console.ReadKey();
                                        Console.Clear();
                                        break;
                                    case 3:
                                        int partnetIdinput;
                                        if (sumOfPartners >= 0)
                                        {
                                            Console.WriteLine("Enter partner ID OR Add new partner by typing 1");
                                            partnetIdinput = int.Parse(Console.ReadLine());
                                            if (partnetIdinput == 1)
                                            {
                                                Console.Write("Enter a First Name: ");
                                                string firstNamePartner = Console.ReadLine();
                                                Console.Write("\nEnter a Last Name: ");
                                                string lastNamePartner = Console.ReadLine();
                                                Console.Write("\nEnter a ID - (6 Digits or More): ");
                                                int idPartner = int.Parse(Console.ReadLine());
                                                int yearDatePartner, monthDatePartner, dayDatePartner;
                                                if ((!(idPartner > 99999)) || IsCheckDiverId(diversUserArray, idPartner))
                                                {
                                                    Console.WriteLine("**Sorry but Incorrect ID or User Exsit..\nPress any key to continue... ");
                                                    Console.ReadKey();
                                                    Console.Clear();
                                                    break;
                                                }
                                                try
                                                {
                                                    Console.WriteLine("\nEnter a Birth-Day:");
                                                    Console.Write("Year (format yyyy): ");
                                                    yearDatePartner = int.Parse(Console.ReadLine());
                                                    Console.Write("Month (format mm): ");
                                                    monthDatePartner = int.Parse(Console.ReadLine());
                                                    Console.Write("Day (format dd): ");
                                                    dayDatePartner = int.Parse(Console.ReadLine());
                                                    CheckDateFormat(yearDatePartner, monthDatePartner, dayDatePartner);
                                                }
                                                catch (Exception e)
                                                {
                                                    Console.WriteLine($"Exeption: {e.Message}\nPress any key to continue... ");
                                                    Console.ReadKey();
                                                    Console.Clear();
                                                    break;
                                                }
                                                Console.Write("\nEnter a Email:");
                                                string emailPartner = Console.ReadLine();
                                                if (!(emailPartner.Length >= 6))
                                                {
                                                    Console.WriteLine("**Invalid Email address");
                                                    Console.ReadKey();
                                                    Console.Clear();
                                                    break;
                                                }
                                                Console.Write("\nEnter a Password:");
                                                string passwordPartner = Console.ReadLine();
                                                if (!(passwordPartner.Length >= 8))
                                                {
                                                    Console.WriteLine("**Password to Short");
                                                    Console.ReadKey();
                                                    Console.Clear();
                                                    break;
                                                }
                                                for (int ind = 0; ind < diversUserArray.Length; ind++)
                                                {
                                                    if (diversUserArray[ind] == null)
                                                    {
                                                        DateTime dateTimePartner = new DateTime(yearDatePartner, monthDatePartner, dayDatePartner);
                                                        diversUserArray[ind] = new Diver(idPartner, firstNamePartner, lastNamePartner, dateTimePartner, emailPartner, passwordPartner);
                                                        Console.WriteLine(ind);
                                                        Console.WriteLine($"{firstNamePartner} was added Successfuly");
                                                        currentPartnersArray[sumOfPartners] = new Diver(diversUserArray[ind].GetIdDiver(), diversUserArray[ind].GetFirstNameDiver(), diversUserArray[ind].GetLastNameDiver(), diversUserArray[ind].GetBirthDateDiver(), diversUserArray[ind].GetEmailDiver(), diversUserArray[ind].GetPasswordDiver());
                                                        sumOfPartners++;
                                                        break;
                                                    }
                                                }
                                            }
                                            else if (partnetIdinput != 1)
                                            {
                                                for (int b = 0; b < diversUserArray.Length; b++)
                                                {
                                                    if ((IsPartnerExis(currentPartnersArray, partnetIdinput)) || (diversUserArray[i].GetIdDiver().Equals(partnetIdinput)))
                                                    {
                                                        Console.WriteLine("Partner Exist!..\nPress any key to continue... ");
                                                        break;
                                                    }
                                                    else if (diversUserArray[b].GetIdDiver().Equals(partnetIdinput))
                                                    {

                                                        currentPartnersArray[sumOfPartners] = new Diver(diversUserArray[b].GetIdDiver(), diversUserArray[b].GetFirstNameDiver(), diversUserArray[b].GetLastNameDiver(), diversUserArray[b].GetBirthDateDiver(), diversUserArray[b].GetEmailDiver(), diversUserArray[b].GetPasswordDiver());
                                                        Console.WriteLine($"{diversUserArray[b].GetFirstNameDiver()} is your Partner Now!");
                                                        sumOfPartners++;
                                                        break;
                                                    }
                                                    if (diversUserArray[b] == null)
                                                    {
                                                        Console.WriteLine("Not Found User ID, Try Again!..\nPress any key to continue... ");
                                                        break;
                                                    }
                                                }
                                                Console.ReadKey();
                                                Console.Clear();
                                                break;
                                            }
                                        }

                                        Console.ReadKey();
                                        Console.Clear();
                                        break;
                                    case 4:
                                        Console.Write("Enter a Country Name:");
                                        string chooseCountryName = Console.ReadLine();
                                        for (int countryIndex = 0; countryIndex < countryArray.Length; countryIndex++)
                                        {
                                            if (countryArray[countryIndex].GetCountryName() == null)
                                            {
                                                break;
                                            }
                                            if (countryArray[countryIndex].GetCountryName().Equals(chooseCountryName))
                                            {
                                                Console.WriteLine(countryArray[countryIndex].ToString());
                                                break;
                                            }
                                        }
                                        Console.ReadKey();
                                        Console.Clear();
                                        break;
                                    case 5:
                                        bool flag = false;
                                        Console.WriteLine(diversUserArray[i].ToString());


                                        Console.WriteLine("Your Dives with Partners:");
                                        for (int tk = 0; tk < currentLogBook.Length; tk++)
                                        {
                                            while (currentLogBook[tk] != null)
                                            {
                                                if (diversUserArray[i].GetFirstNameDiver().Equals(currentLogBook[tk].GetPartnerName()))
                                                {
                                                    Console.WriteLine(currentLogBook[tk]);
                                                    Console.WriteLine($"\tDived with: {currentLogBook[tk].GetDiverName()}");
                                                    Console.WriteLine("Equipment:\n");
                                                    if (currentLogBook[tk].GetEquipmentArray() != null)
                                                    {
                                                        for (int equipPartner = 0; equipPartner < currentLogBook[tk].GetEquipmentArray().Length; equipPartner++)
                                                        {
                                                            if (currentLogBook[tk].GetEquipmentArray()[equipPartner] != null)
                                                            {
                                                                Console.WriteLine(currentLogBook[tk].GetEquipmentArray()[equipPartner].ToString());

                                                            }
                                                        }
                                                    }
                                                    flag = true;
                                                    break;
                                                }
                                                else
                                                {
                                                    break;
                                                }
                                            }
                                        }

                                        Console.WriteLine("\n\nYour Dives:");

                                        for (int ck = 0; ck < currentLogBook.Length; ck++)
                                        {
                                            while (currentLogBook[ck] != null)
                                            {
                                                if (diversUserArray[i].GetFirstNameDiver().Equals(currentLogBook[ck].GetDiverName()))
                                                {
                                                    Console.WriteLine(currentLogBook[ck]);
                                                    Console.WriteLine($"\tDived with: {currentLogBook[ck].GetPartnerName()}");
                                                    Console.WriteLine("Equipment:\n");
                                                    if (currentLogBook[ck].GetEquipmentArray() != null)
                                                    {
                                                        for (int equip = 0; equip < currentLogBook[ck].GetEquipmentArray().Length; equip++)
                                                        {
                                                            if (currentLogBook[ck].GetEquipmentArray()[equip] != null)
                                                            {
                                                                Console.WriteLine(currentLogBook[ck].GetEquipmentArray()[equip].ToString());
                                                            }
                                                        }
                                                    }
                                                    break;
                                                }
                                                else if (flag)
                                                {
                                                    break;
                                                }

                                                else
                                                {
                                                    Console.WriteLine("Ther'e are no Dives!!");
                                                    break;
                                                }
                                            }
                                        }
                                        Console.ReadKey();
                                        Console.Clear();
                                        break;
                                    case 6:
                                        if (divingClubs[choiceClubFromList - 1].GetClubName() != null)
                                        {
                                            Console.WriteLine(divingClubs[choiceClubFromList - 1].ToString());
                                        }
                                        else
                                            Console.WriteLine("You need to choose a diving club. Try again");
                                        Console.ReadKey();
                                        Console.Clear();
                                        break;
                                    case 7:
                                        choiceClubFromList = 7;
                                        sumOfPartners = 0;
                                        for (int e = 0; e < currentPartnersArray.Length; e++)
                                        {
                                            currentPartnersArray[e] = null;
                                        }
                                        break;

                                    default:
                                        Console.Clear();
                                        break;
                                }
                            } while (choiceUserMenuLogin != 7);
                            Console.WriteLine("Press Enter To Continue..");
                            break;
                        }
                    }
                }
                if (choiceUserMenuLogin != 6)
                    Console.WriteLine("Incorrect Login, Press Enter To Continue..");

            }
            void CaseRegister()
            {
                Console.WriteLine("\n\nWelcome To Register System DeepDiver!\n======================================\nPlease Fill The Following:\n");
                Console.Write("Enter a First Name: ");
                string firstNameRegister = Console.ReadLine();
                Console.Write("\nEnter a Last Name: ");
                string lastNameRegister = Console.ReadLine();
                Console.Write("\nEnter a ID - (6 Digits or More): ");
                int idRegister = int.Parse(Console.ReadLine());
                int yearDateRegister, monthDateRegister, dayDateRegister;
                if ((!(idRegister > 99999)) || IsCheckDiverId(diversUserArray, idRegister))
                {
                    Console.WriteLine("**Incorrect ID or User Exist , Try Again\nPress any key to continue... ");
                    return;
                }
                try
                {
                    Console.WriteLine("\nEnter a Birth-Day:");
                    Console.Write("Year (format yyyy): ");
                    yearDateRegister = int.Parse(Console.ReadLine());
                    Console.Write("Month (format mm): ");
                    monthDateRegister = int.Parse(Console.ReadLine());
                    Console.Write("Day (format dd): ");
                    dayDateRegister = int.Parse(Console.ReadLine());
                    CheckDateFormat(yearDateRegister, monthDateRegister, dayDateRegister);
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Exeption: {e.Message}\nPress any key to continue... ");
                    return;
                }
                Console.Write("\nEnter a Email:");
                string emailRegister = Console.ReadLine();
                if (!(emailRegister.Length >= 6))
                {
                    Console.WriteLine("**Invalid Email address");
                    return;
                }
                Console.Write("\nEnter a Password:");
                string passwordRegister = Console.ReadLine();
                if (!(passwordRegister.Length >= 8))
                {
                    Console.WriteLine("**Password to Short");
                    return;
                }
                for (int i = 0; i < diversUserArray.Length; i++)
                {
                    if (diversUserArray[i] == null)
                    {
                        DateTime dateTimeRegister = new DateTime(yearDateRegister, monthDateRegister, dayDateRegister);
                        diversUserArray[i] = new Diver(idRegister, firstNameRegister, lastNameRegister, dateTimeRegister, emailRegister, passwordRegister);
                        Console.WriteLine(i);
                        Console.WriteLine($"{firstNameRegister} was added Successfuly");
                        break;
                    }
                }
            }
        }

        public static void CheckDateFormat(int yy, int mm, int dd)
        {
            if ((!(yy >= 1940 && yy <= 2022)) || (!(mm >= 1 && mm <= 12)) || (!(dd >= 1 && dd <= 31)))
            {
                throw new OverflowException("The Date You Typed Is Invalid. Please Try again!");

            }
        }

        public static bool IsPartnerExis(Diver[] partners, int currentPartner)
        {
            for (int i = 0; i < partners.Length; i++)
            {
                if (partners[i] != null)
                {
                    if (partners[i].GetIdDiver().Equals(currentPartner))
                    {
                        return true;
                    }
                }
            }
            return false;
        }


        public static bool IsCheckDiverId(Diver[] usersArray, int idInput)
        {
            for (int i = 0; i < usersArray.Length; i++)
            {
                if (usersArray[i] != null)
                {
                    if (usersArray[i].GetIdDiver().Equals(idInput))
                    {
                        return true;
                    }
                }
            }
            return false;
        }


    }
}
