﻿namespace Ex_Divers_OPP_17_12_21
{
    class Sign
    {
        protected string sign;

        public Sign(string sign)
        {
            SetSign(sign);
        }

        public string GetSign() { return sign; }
        public void SetSign(string sign) { this.sign = sign; }

        public override string ToString()
        {
            return $"{sign}";
        }


    }
}
