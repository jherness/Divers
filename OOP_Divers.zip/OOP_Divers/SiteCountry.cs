﻿

namespace Ex_Divers_OPP_17_12_21
{
    class SiteCountry
    {
        string sites, waterType;
        double depth;

        public SiteCountry(string sites, string waterType, double depth)
        {
            this.sites = sites;
            this.waterType = waterType;
            this.depth = depth;
        }
        public SiteCountry()
        {

        }
        public SiteCountry(SiteCountry objSiteCountry)
        {
            this.sites = objSiteCountry.sites;
            this.waterType = objSiteCountry.waterType;
            this.depth = objSiteCountry.depth;
        }
        public string GetSiteName() { return sites; }
        public void SetSiteName(string sites) { this.sites = sites; }

        public double GetDepth() { return depth; }
        public void SetDepth(double depth) { this.depth = depth; }

        public string GetWaterType() { return waterType; }
        public void SetWaterType(string waterType) { this.waterType = waterType; }

        public override string ToString()
        {
            return $"Site Name: {sites}   Water Type: {waterType}   Depth: {depth}";
        }
    }
}
